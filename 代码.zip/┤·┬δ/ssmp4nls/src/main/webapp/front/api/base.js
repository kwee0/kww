﻿const base = {
    url : "http://localhost:8080/ssmp4nls/"
}
export default base
